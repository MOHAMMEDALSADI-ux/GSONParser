package testGson.parser;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import com.google.gson.Gson;

import testGson.Models.Model;
import testGson.Models.Parameters;
import testGson.Table.InsertToTable;

public class JSONParser {

	public void parser() throws FileNotFoundException, SQLException {

		Gson gson = new Gson();
		Model model = new Model();

		BufferedReader reader = new BufferedReader(new FileReader(
				"C:\\Users\\m.alsadi\\eclipse-workspace\\GSON_PROJECT\\src\\main\\resources\\Employee.json"));

		model = gson.fromJson(reader, Model.class);

		List<Parameters> list = model.getData().getParameters();

		String requesId = model.getRequestId();

		for (int i = 0; i < list.size(); i++) {

			String eventCode = list.get(i).getEventCode();
			String city = list.get(i).getCity();
			String firstname = list.get(i).getFirstName();
			String lastname = list.get(i).getLastName();
			String create_date = datetime();

			InsertToTable toTable = new InsertToTable();

			toTable.insert(eventCode, requesId, city, firstname, lastname, create_date);
		}
	}

	// TODO Method For Get Date and time (Create_Date)
	static public String datetime() {

		// Create Date and Time For DataBase Record
		DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime time = LocalDateTime.now();
		String dateTime = date.format(time);

		return dateTime;
	}
}
