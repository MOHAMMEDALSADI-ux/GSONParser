package testGson.Table;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertToTable {

	public void insert(String eventCode, String requesId, String city, String firstname, String lastname,
			String create_date) throws SQLException {

		PreparedStatement preparedStatement = null;
		Connection connection = null;

		try {

			// Method for open Connection With the dataBase
			connection = DBConnection.getConnection();

			String query = "INSERT INTO bsa_transactions (EVENT_CODE, requestId, City, FirstName, LastName, response_message , CREATE_DATE , REPLY_DATE , IS_executuig) VALUES (?, ?, ?, ?, ?, ? , ? ,? ,?)";

			preparedStatement = connection.prepareStatement(query);

			preparedStatement.setString(1, eventCode);
			preparedStatement.setString(2, requesId);
			preparedStatement.setString(3, city);
			preparedStatement.setString(4, firstname);
			preparedStatement.setString(5, lastname);
			preparedStatement.setString(6, "");
			preparedStatement.setString(7, create_date);
			preparedStatement.setString(8, "");
			preparedStatement.setBoolean(9, false);

			preparedStatement.execute();


		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			preparedStatement.close();
		}

	}

}
