package testGson.main;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import testGson.parser.JSONParser;

public class Main {

	public static void main(String[] args) throws FileNotFoundException, SQLException {

		JSONParser jsonParser = new JSONParser();

		jsonParser.parser();

	}
}
